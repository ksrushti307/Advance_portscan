import customtkinter as ctk
from tkinter import ttk, messagebox
from PIL import Image
import socket
import threading
import os
import csv
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    Image as RLImage
)

from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import letter

# =========================================================
# CONFIGURATION
# =========================================================

APP_NAME = "NetX Scanner PRO ⚡"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

REPORTS = "reports"

BACKGROUND_IMAGE = "background.jpeg"
LOGO_IMAGE = "newlogo.jpeg"

os.makedirs(REPORTS, exist_ok=True)

# =========================================================
# APP INFO
# =========================================================

APP_INFO = """
╔══════════════════════════════════════╗
        NETX SCANNER PRO ⚡
╚══════════════════════════════════════╝

Developer Team:
• Srushti K
• Tejashwini
• Poorvi Salimath
• Jayashree M

Version:
v3.0 Professional Edition

Technology:
• Python
• CustomTkinter
• Socket Programming
• ThreadPoolExecutor

Features:
✔ TCP/UDP Port Scanning
✔ Banner Grabbing
✔ Open/Closed Port Detection
✔ Real-Time Dashboard
✔ PDF Report Generation
✔ Cyberpunk UI
✔ Multithreaded Scanner

Scanner Status:
ACTIVE

Thread Pool:
200 Workers Enabled

Security Engine:
READY

Export Support:
✔ PDF
✔ CSV
✔ JSON
✔ TXT

© 2026 NetX Security Labs
"""

# =========================================================
# MAIN APPLICATION
# =========================================================

class NetXScannerPRO(ctk.CTk):

    def __init__(self):

        super().__init__()

        self.title(APP_NAME)
        self.geometry("1600x900")
        self.state("zoomed")

        self.open_ports = []
        self.closed_ports = []

        self.scanning = False

        self.executor = ThreadPoolExecutor(max_workers=200)

        self.show_splash_screen()

    # =====================================================
    # SPLASH SCREEN
    # =====================================================

    def show_splash_screen(self):

        self.splash_frame = ctk.CTkFrame(self)
        self.splash_frame.pack(fill="both", expand=True)

        bg_img = ctk.CTkImage(
            light_image=Image.open(BACKGROUND_IMAGE),
            dark_image=Image.open(BACKGROUND_IMAGE),
            size=(1920, 1080)
        )

        bg_label = ctk.CTkLabel(
            self.splash_frame,
            image=bg_img,
            text=""
        )

        bg_label.place(relwidth=1, relheight=1)

        # MAIN CARD
        self.card = ctk.CTkFrame(
            self.splash_frame,
            width=650,
            height=600,
            fg_color="#081120",
            corner_radius=25,
            border_width=2,
            border_color="#00ffff"
        )

        self.card.place(relx=0.5, rely=0.5, anchor="center")

        # LOGO
        logo_img = ctk.CTkImage(
            light_image=Image.open(LOGO_IMAGE),
            dark_image=Image.open(LOGO_IMAGE),
            size=(150, 150)
        )

        logo = ctk.CTkLabel(
            self.card,
            image=logo_img,
            text=""
        )

        logo.pack(pady=(30, 10))

        # TITLE
        title = ctk.CTkLabel(
            self.card,
            text="⚡ NetX Scanner PRO",
            font=("Consolas", 34, "bold"),
            text_color="#00ffff"
        )

        title.pack(pady=10)

        subtitle = ctk.CTkLabel(
            self.card,
            text="Advanced Cybersecurity Port Scanner",
            font=("Consolas", 17),
            text_color="white"
        )

        subtitle.pack()

        # PROGRESS BAR
        self.progress = ctk.CTkProgressBar(
            self.card,
            width=350,
            progress_color="#00ffff"
        )

        self.progress.pack(pady=25)
        self.progress.set(0)

        self.animate_progress()

        # START BUTTON
        start_btn = ctk.CTkButton(
            self.card,
            text="START",
            width=260,
            height=55,
            fg_color="#00c8ff",
            hover_color="#00ffff",
            text_color="black",
            font=("Consolas", 20, "bold"),
            corner_radius=15,
            command=self.open_dashboard
        )

        start_btn.pack(pady=15)

        # APP INFO BUTTON
        info_btn = ctk.CTkButton(
            self.card,
            text="APP INFO",
            width=260,
            height=50,
            fg_color="#673ab7",
            hover_color="#7c4dff",
            font=("Consolas", 18, "bold"),
            command=self.show_app_info
        )

        info_btn.pack(pady=10)

    # =====================================================
    # APP INFO WINDOW
    # =====================================================

    def show_app_info(self):

        info_window = ctk.CTkToplevel(self)

        info_window.title("Application Information")
        info_window.geometry("700x650")

        info_frame = ctk.CTkScrollableFrame(
            info_window,
            width=650,
            height=600,
            fg_color="#081120"
        )

        info_frame.pack(fill="both", expand=True, padx=15, pady=15)

        info_label = ctk.CTkLabel(
            info_frame,
            text=APP_INFO,
            justify="left",
            font=("Consolas", 14),
            text_color="#00ffcc"
        )

        info_label.pack(anchor="w", padx=15, pady=15)

    # =====================================================
    # ANIMATION
    # =====================================================

    def animate_progress(self):

        current = self.progress.get()

        if current < 1:

            self.progress.set(current + 0.01)
            self.after(300, self.animate_progress)

        else:

            self.progress.set(0)
            self.after(1200, self.animate_progress)

    # =====================================================
    # DASHBOARD
    # =====================================================

    def open_dashboard(self):

        self.splash_frame.destroy()

        self.dashboard = ctk.CTkFrame(
            self,
            fg_color="#050816"
        )

        self.dashboard.pack(fill="both", expand=True)

        # TITLE
        title = ctk.CTkLabel(
            self.dashboard,
            text="⚡ CYBERSECURITY DASHBOARD",
            font=("Consolas", 34, "bold"),
            text_color="#00ffff"
        )

        title.pack(pady=15)

        # =================================================
        # INPUT FRAME
        # =================================================

        input_frame = ctk.CTkFrame(
            self.dashboard,
            fg_color="#0b1220",
            corner_radius=20
        )

        input_frame.pack(fill="x", padx=20, pady=10)

        # TARGET IP
        self.ip_entry = ctk.CTkEntry(
            input_frame,
            placeholder_text="Target IP Address",
            width=250,
            height=45
        )

        self.ip_entry.grid(row=0, column=0, padx=10, pady=20)

        # START PORT
        self.start_port = ctk.CTkEntry(
            input_frame,
            placeholder_text="Start Port",
            width=140,
            height=45
        )

        self.start_port.grid(row=0, column=1, padx=10)

        # END PORT
        self.end_port = ctk.CTkEntry(
            input_frame,
            placeholder_text="End Port",
            width=140,
            height=45
        )

        self.end_port.grid(row=0, column=2, padx=10)

        # PROTOCOL
        self.protocol = ctk.CTkComboBox(
            input_frame,
            values=["TCP", "UDP", "BOTH"],
            width=160,
            height=45
        )

        self.protocol.grid(row=0, column=3, padx=10)
        self.protocol.set("TCP")

        # SCAN TYPE
        self.scan_type = ctk.CTkComboBox(
            input_frame,
            values=["Quick Scan", "Full Scan", "Stealth Scan"],
            width=170,
            height=45
        )

        self.scan_type.grid(row=0, column=4, padx=10)
        self.scan_type.set("Quick Scan")

        # START BUTTON
        start_btn = ctk.CTkButton(
            input_frame,
            text="START SCAN",
            width=50,
            height=45,
            fg_color="#00c8ff",
            hover_color="#00ffff",
            text_color="black",
            font=("Consolas", 15, "bold"),
            command=self.start_scan
        )

        start_btn.grid(row=0, column=5, padx=4)

        # STOP BUTTON
        stop_btn = ctk.CTkButton(
            input_frame,
            text="STOP",
            width=40,
            height=45,
            fg_color="#ff4444",
            hover_color="#ff0000",
            font=("Consolas", 15, "bold"),
            command=self.stop_scan
        )

        stop_btn.grid(row=0, column=6, padx=4)

        # REPORT BUTTON
        report_btn = ctk.CTkButton(
            input_frame,
            text="EXPORT REPORT",
            width=30,
            height=45,
            fg_color="#673ab7",
            hover_color="#7c4dff",
            font=("Consolas", 15, "bold"),
            command=self.export_pdf
        )

        report_btn.grid(row=0, column=7, padx=4)

        # =================================================
        # PROGRESS BAR
        # =================================================

        self.progress_bar = ctk.CTkProgressBar(
            self.dashboard,
            width=1300,
            progress_color="#00ffff"
        )

        self.progress_bar.pack(pady=15)
        self.progress_bar.set(0)

        # =================================================
        # OPEN PORTS
        # =================================================

        open_label = ctk.CTkLabel(
            self.dashboard,
            text="OPEN PORTS",
            font=("Consolas", 24, "bold"),
            text_color="#00ff99"
        )

        open_label.pack(pady=5)

        open_frame = ctk.CTkFrame(self.dashboard)
        open_frame.pack(fill="both", expand=True, padx=20)

        columns = (
            "Port",
            "Service",
            "Protocol",
            "Status",
            "Banner",
            "Risk"
        )

        self.open_table = ttk.Treeview(
            open_frame,
            columns=columns,
            show="headings",
            height=10
        )

        for col in columns:

            self.open_table.heading(col, text=col)
            self.open_table.column(col, width=150)

        self.open_table.pack(fill="both", expand=True)

        # =================================================
        # CLOSED PORTS
        # =================================================

        closed_label = ctk.CTkLabel(
            self.dashboard,
            text="CLOSED PORTS",
            font=("Consolas", 24, "bold"),
            text_color="#ff5555"
        )

        closed_label.pack(pady=5)

        closed_frame = ctk.CTkFrame(self.dashboard)

        closed_frame.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=15
        )

        closed_columns = (
            "Port",
            "Protocol",
            "Status"
        )

        self.closed_table = ttk.Treeview(
            closed_frame,
            columns=closed_columns,
            show="headings",
            height=8
        )

        for col in closed_columns:

            self.closed_table.heading(col, text=col)
            self.closed_table.column(col, width=200)

        self.closed_table.pack(fill="both", expand=True)

    # =====================================================
    # START SCAN
    # =====================================================

    def start_scan(self):

        if self.scanning:
            return

        self.scanning = True

        self.open_ports.clear()
        self.closed_ports.clear()

        for item in self.open_table.get_children():
            self.open_table.delete(item)

        for item in self.closed_table.get_children():
            self.closed_table.delete(item)

        threading.Thread(
            target=self.scan_ports,
            daemon=True
        ).start()

    # =====================================================
    # SCAN PORTS
    # =====================================================

    def scan_ports(self):

        target = self.ip_entry.get()

        try:

            start = int(self.start_port.get())
            end = int(self.end_port.get())

        except:

            messagebox.showerror(
                "Error",
                "Invalid Port Range"
            )

            return

        total_ports = end - start + 1

        for index, port in enumerate(range(start, end + 1)):

            if not self.scanning:
                break

            self.executor.submit(
                self.scan_single_port,
                target,
                port,
                total_ports,
                index
            )

    # =====================================================
    # SINGLE PORT SCAN
    # =====================================================

    def scan_single_port(self, target, port, total, index):

        try:

            sock = socket.socket(
                socket.AF_INET,
                socket.SOCK_STREAM
            )

            sock.settimeout(0.5)

            result = sock.connect_ex((target, port))

            protocol = self.protocol.get()

            if result == 0:

                try:
                    service = socket.getservbyport(port)
                except:
                    service = "Unknown"

                try:

                    sock.send(b"HELLO\r\n")

                    banner = sock.recv(1024).decode().strip()

                    if not banner:
                        banner = "No Banner"

                except:

                    banner = "No Banner"

                risk = self.get_risk(port)

                self.open_ports.append([
                    port,
                    service,
                    protocol,
                    "OPEN",
                    banner,
                    risk
                ])

                self.open_table.insert(
                    "",
                    "end",
                    values=(
                        port,
                        service,
                        protocol,
                        "OPEN",
                        banner,
                        risk
                    )
                )

            else:

                self.closed_ports.append([
                    port,
                    protocol,
                    "CLOSED"
                ])

                self.closed_table.insert(
                    "",
                    "end",
                    values=(
                        port,
                        protocol,
                        "CLOSED"
                    )
                )

            progress = (index + 1) / total

            self.progress_bar.set(progress)

            sock.close()

        except:
            pass

    # =====================================================
    # RISK ANALYSIS
    # =====================================================

    def get_risk(self, port):

        high_risk = [21, 23, 25, 3389]
        medium_risk = [80, 443, 8080]

        if port in high_risk:
            return "HIGH"

        elif port in medium_risk:
            return "MEDIUM"

        return "LOW"

    # =====================================================
    # STOP SCAN
    # =====================================================

    def stop_scan(self):

        self.scanning = False

        messagebox.showwarning(
            "Scanner",
            "Scanning Stopped"
        )

    # =====================================================
    # EXPORT PDF REPORT
    # =====================================================

    def export_pdf(self):

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        filename = os.path.join(
            REPORTS,
            f"NetX_Report_{timestamp}.pdf"
        )

        doc = SimpleDocTemplate(
            filename,
            pagesize=letter
        )

        styles = getSampleStyleSheet()

        elements = []

        # LOGO
        if os.path.exists(LOGO_IMAGE):

            logo = RLImage(
                LOGO_IMAGE,
                width=100,
                height=100
            )

            elements.append(logo)

        elements.append(
            Paragraph(
                "<b>NETX SCANNER PRO REPORT</b>",
                styles['Title']
            )
        )

        elements.append(Spacer(1, 20))

        elements.append(
            Paragraph(
                f"Generated : {datetime.now()}",
                styles['Normal']
            )
        )

        elements.append(
            Paragraph(
                f"Target IP : {self.ip_entry.get()}",
                styles['Normal']
            )
        )

        elements.append(Spacer(1, 20))

        # OPEN PORTS TABLE
        elements.append(
            Paragraph(
                "<b>OPEN PORTS</b>",
                styles['Heading2']
            )
        )

        open_data = [
            ["Port", "Service", "Protocol", "Status", "Banner", "Risk"]
        ] + self.open_ports

        open_table = Table(open_data)

        open_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.black),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.cyan),
            ('GRID', (0, 0), (-1, -1), 1, colors.white),
            ('BACKGROUND', (0, 1), (-1, -1), colors.darkgrey)
        ]))

        elements.append(open_table)

        elements.append(Spacer(1, 20))

        # CLOSED PORTS TABLE
        elements.append(
            Paragraph(
                "<b>CLOSED PORTS</b>",
                styles['Heading2']
            )
        )

        closed_data = [
            ["Port", "Protocol", "Status"]
        ] + self.closed_ports

        closed_table = Table(closed_data)

        closed_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.black),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.red),
            ('GRID', (0, 0), (-1, -1), 1, colors.white),
            ('BACKGROUND', (0, 1), (-1, -1), colors.darkgrey)
        ]))

        elements.append(closed_table)

        elements.append(Spacer(1, 30))

        elements.append(
            Paragraph(
                "Generated by NetX Scanner PRO ⚡",
                styles['Italic']
            )
        )

        doc.build(elements)

        messagebox.showinfo(
            "PDF Exported",
            f"Report Saved:\n{filename}"
        )
        os.startfile(filename)

# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":

    app = NetXScannerPRO()

    app.mainloop()